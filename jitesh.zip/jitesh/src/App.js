// import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
import About from './components/About';
import { useState } from 'react';
import Alert from './components/Alert';


let name=" Jitesh Kaushik"
function App() {
 const [ mode, setMode]= useState('light');

 const[alert,setAlert] =useState(null)

 const showAlert = (message,type)=>{
  setAlert({
    msg:message,
    type:type
  })
  setTimeout(() =>{
    setAlert(null);
  },3000)
 }

const toggleMode= () =>{
  if(mode ==='light'){
    setMode('dark');
     document.body.style.background ='#042743'
     showAlert( "dark mode has been enable","Success")
  }
  else{
    setMode('light')
    document.body.style.background ='white'
    showAlert("Light mode has been enable","Success")
  }
}

  return (
    <>
{/* <Navbar title="ya props ka used h" aboutText="About us" /> */}
<Navbar mode={mode} toggleMode={toggleMode} />
<div className="container bg-success">
<Alert alert={alert}/>
</div>
<div className="container ">
<TextForm showAlert={showAlert} heading="Enter the text to analyze"  mode={mode}/>
<About/>
</div>
   </>
   
  );
}

export default App;
