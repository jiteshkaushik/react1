import React,{useState} from 'react'


function TextForm(props) {

    const handleUpClick =() =>{
        // console.log("Uppercase was Clicked"+text)
        let newText = text.toUpperCase()
        setText(newText)
        props.showAlert("Converted to uppercase","sucess")
    }

    const handleLoClick =() =>{
        let newText = text.toLowerCase()
        setText(newText)
        props.showAlert("Converted to Lowercase","sucess")

    }

    const handleClearClick =() =>{
        let newText = '';
        setText(newText)
        props.showAlert("Clear text","sucess")

    }
    const backgroundColor = "white"

    const handleChangeBackground =() =>{
    //    document.getElementById("myBox").style.backgroundColor= "red"

    if(backgroundColor === "white"){
       document.getElementById("myBox").style.backgroundColor= "red"          
    //  document.body.style.background ='#042743'

    }else if(backgroundColor === "red"){
       document.getElementById("myBox").style.background= "blue"          

    }
    }

    const handleChangeBackground2 =() =>{
        document.getElementById("myBox").style.backgroundColor= "green"
     }

    const handleColorClick =() =>{
        document.getElementById("myBox").style.color = "blue";
        document.getElementById("myBox").style.letterSpacing = "10px";
        document.getElementById("myBox").style.textTransform = "uppercase";
        document.getElementById("myBox").style.fontSize = "20px";
        props.showAlert("Converted to color and space","sucess")

    }

    const handleCopyClick = () =>{
        var text =document.getElementById("myBox")
        text.select();
        navigator.clipboard.writeText(text.value);
        props.showAlert("Copy text","success")

    }

    const handleExtraSpaces = () =>{
        let newText = text.split(/[ ]+/);
        setText(newText.join(" "))
        props.showAlert("Remove Extra Spaces","sucess")

    }

    const handleOnClick =(event) =>{
        // console.log("On Change")
        setText(event.target.value)
    }

const [text,setText]=useState('')

  return (
    <>

    <div className="container"  style={{color:props.mode ==='dark'?'white':'black'}}>
    <h1>{props.heading}</h1>
<div class="mb-3">
  <textarea class="form-control" id="myBox" value={text} onChange={handleOnClick}  style={{backgroundColor:props.mode ==='dark'?'gray':'white',border:'2px solid  ' }} rows="8" placeholder='Enter the text'></textarea>
</div>

{/* first projects */}

<button className="btn btn-primary" onClick={handleUpClick}>Convert to Uppercase </button>
<button className="btn btn-primary ms-2" onClick={handleLoClick}>Convert to Lowercase </button>
<button className="btn btn-primary ms-2" onClick={handleClearClick}>Clear Text </button>
<button className="btn btn-primary ms-2" onClick={handleColorClick}>Color change </button>
<button className="btn btn-primary ms-2" onClick={handleCopyClick}>Copy text </button>
<button className="btn btn-primary ms-2" onClick={handleExtraSpaces}>Remove Extra Spaces</button>
<button className="btn btn-primary ms-2 bg-danger border" onClick={handleChangeBackground}>Change Background color</button>
<button className="btn btn-primary ms-2 bg-success border" onClick={handleChangeBackground2}>Change Background color</button>
</div>

{/* second projects  */}

<div className="container my-3">
    <h2 style={{color:props.mode ==='dark'?'white':'black'}}>Your text summart </h2>
    <p style={{color:props.mode ==='dark'?'red':'green'}}> {text.split(" ").length} and {text.length} characters</p>

    {/* third project */}
    <p> {0.008 * text.split(" ").length} time to read words</p>

    {/* foruth projects  */}
    <h2 style={{color:props.mode ==='dark'?'white':'black'}}>Preview</h2>
    <p style={{color:props.mode ==='dark'?'white':'black'}}>{text.length>0?text:"enter something in box"}  </p>
</div>

</>
  )
}

export default TextForm;